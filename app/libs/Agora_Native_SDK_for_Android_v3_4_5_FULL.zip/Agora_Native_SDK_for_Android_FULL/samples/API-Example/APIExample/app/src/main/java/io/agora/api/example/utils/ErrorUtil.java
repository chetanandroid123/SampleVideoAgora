package io.agora.api.example.utils;

import io.agora.api.component.Constant;
import io.agora.rtc.Constants;
import io.agora.rtc.RtcEngine;

/**
 * @author cjw
 */
public class ErrorUtil {
}
