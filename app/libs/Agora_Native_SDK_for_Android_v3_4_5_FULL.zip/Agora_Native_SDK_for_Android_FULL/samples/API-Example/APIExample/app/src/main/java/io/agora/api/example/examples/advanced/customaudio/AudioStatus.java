package io.agora.api.example.examples.advanced.customaudio;

public enum AudioStatus {
    INITIALISING,
    RUNNING,
    STOPPED
}
