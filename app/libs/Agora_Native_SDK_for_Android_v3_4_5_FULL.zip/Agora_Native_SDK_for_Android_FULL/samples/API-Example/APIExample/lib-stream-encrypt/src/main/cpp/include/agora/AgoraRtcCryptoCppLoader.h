//
//  AgoraRtcCryptoCppLoader.h
//  AgoraRtcCryptoLoader
//
//  Copyright © 2019 Agora IO. All rights reserved.
//

#ifndef AgoraRtcCryptoCppLoader_h
#define AgoraRtcCryptoCppLoader_h

class AgoraRtcCryptoCppLoader
{
public:
    AgoraRtcCryptoCppLoader();
    ~AgoraRtcCryptoCppLoader();
};

#endif /* AgoraRtcCryptoCppLoader_h */
